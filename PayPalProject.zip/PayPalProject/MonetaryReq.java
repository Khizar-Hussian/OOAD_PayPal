package  PayPalProject;
import java.util.*;

/**
 * 
 */
public class MonetaryReq extends Request {

	/**
	 * Default constructor
	 */
	public MonetaryReq() {
	}

	/**
	 * 
	 */
	public Double amount;

	/**
	 * 
	 */
	public UserAccount requestee;


	/**
	 * @return
	 */
	public Boolean processRequest() {
		// TODO implement here
		return null;
	}

}