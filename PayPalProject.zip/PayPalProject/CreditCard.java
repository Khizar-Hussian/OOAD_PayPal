package  PayPalProject;
import java.util.*;

/**
 * 
 */
public class CreditCard {

	/**
	 * Default constructor
	 */
	public CreditCard() {
	}

	/**
	 * 
	 */
	public Date expirationDate;

	/**
	 * 
	 */
	public int cvv;

	/**
	 * 
	 */
	public String cardNum;

	/**
	 * 
	 */
	private Double balance;


	/**
	 * @return
	 */
	public void printInfo() {
		// TODO implement here

	}

	/**
	 * @param amount 
	 * @return
	 */
	public Boolean updateBalance(Double amount) {
		// TODO implement here
		return null;
	}

}