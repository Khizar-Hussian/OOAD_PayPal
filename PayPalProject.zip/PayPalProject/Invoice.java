package  PayPalProject;
import java.util.*;

/**
 * 
 */
public class Invoice {

	/**
	 * Default constructor
	 */
	public Invoice() {
	}

	/**
	 * 
	 */
	public int id;

	/**
	 * 
	 */
	public String receipt;

	/**
	 * 
	 */
	public Double total;

	/**
	 * 
	 */
	public Date dateGenerated;



	/**
	 * @return
	 */
	public void printDetails() {
		// TODO implement here

	}

}