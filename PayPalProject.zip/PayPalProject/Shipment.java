package  PayPalProject;
import java.util.*;

/**
 * 
 */
public class Shipment {

	/**
	 * Default constructor
	 */
	public Shipment() {
	}

	/**
	 * 
	 */
	public String address;

	/**
	 * 
	 */
	public String status;

	/**
	 * 
	 */
	public Date dispatchDate;

	/**
	 * 
	 */
	public Date arrivalDate;

	/**
	 * 
	 */
	public String details;

	/**
	 * 
	 */
	public Double fee;



	/**
	 * @return
	 */
	public void printDetails() {
		// TODO implement here
	}

}