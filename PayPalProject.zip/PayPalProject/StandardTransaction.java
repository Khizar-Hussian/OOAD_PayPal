package  PayPalProject;
import java.util.*;

/**
 * 
 */
public class StandardTransaction extends Transaction {

	/**
	 * Default constructor
	 */
	public StandardTransaction() {
	}

	/**
	 * 
	 */
	public UserAccount beneficiary;

	/**
	 * 
	 */
	public UserAccount benefactor;


}