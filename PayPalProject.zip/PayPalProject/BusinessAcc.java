package  PayPalProject;
import java.util.*;

/**
 * 
 */
public class BusinessAcc extends UserAccount {

	/**
	 * Default constructor
	 */
	public BusinessAcc() {
	}

	/**
	 * 
	 */
	public List<BusinessTransaction> transactions;

	/**
	 * 
	 */
	public String businessName;



	/**
	 * @param trans 
	 * @return
	 */
	public Boolean refundTransaction(BusinessTransaction trans) {
		// TODO implement here
		return null;
	}

	/**
	 * @return
	 */
	public void printBusinessTransactions() {
		// TODO implement here

	}

}