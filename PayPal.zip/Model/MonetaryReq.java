
import java.util.*;

/**
 * 
 */
public class MonetaryReq extends Request {

	/**
	 * Default constructor
	 */
	public MonetaryReq() {
	}

	/**
	 * 
	 */
	public Doubele amount;

	/**
	 * 
	 */
	public UserAccount requestee;


	/**
	 * @return
	 */
	public Boolean processRequest() {
		// TODO implement here
		return null;
	}

}