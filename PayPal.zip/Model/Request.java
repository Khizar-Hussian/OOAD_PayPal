
import java.util.*;

/**
 * 
 */
public class Request {

	/**
	 * Default constructor
	 */
	public Request() {
	}

	/**
	 * 
	 */
	public String message;

	/**
	 * 
	 */
	public String status;

	/**
	 * 
	 */
	public int id;

	/**
	 * 
	 */
	public UserAccount requester;


	/**
	 * @return
	 */
	public void printRequest() {
		// TODO implement here
		return null;
	}

}