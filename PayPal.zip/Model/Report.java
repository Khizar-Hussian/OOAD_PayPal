
import java.util.*;

/**
 * 
 */
public class Report extends Request {

	/**
	 * Default constructor
	 */
	public Report() {
	}

	/**
	 * 
	 */
	public String response;

	/**
	 * 
	 */
	public AdminAccount admin;

	/**
	 * 
	 */
	public Account reported;

	/**
	 * @return
	 */
	public void getResponse() {
		// TODO implement here
		return null;
	}

}